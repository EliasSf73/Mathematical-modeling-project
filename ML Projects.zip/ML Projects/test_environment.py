def test_environment():
    print("Testing environment setup...")
    
    # Test PyTorch
    import torch
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    
    # Test TensorFlow
    import tensorflow as tf
    print(f"TensorFlow version: {tf.__version__}")
    
    # Test NumPy
    import numpy as np
    print(f"NumPy version: {np.__version__}")
    
    # Test Matplotlib
    import matplotlib
    print(f"Matplotlib version: {matplotlib.__version__}")
    
    # Test Seaborn
    import seaborn as sns
    print(f"Seaborn version: {sns.__version__}")
    
    # Test WandB
    import wandb
    print(f"WandB version: {wandb.__version__}")
    
    # Test PyTorch Lightning
    import pytorch_lightning as pl
    print(f"PyTorch Lightning version: {pl.__version__}")
    
    print("\nAll packages are installed and working!")

if __name__ == "__main__":
    test_environment()
