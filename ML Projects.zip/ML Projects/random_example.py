import random

# 1. Basic Random Number Generation
# Generate a random float between 0 and 1
random_float = random.random()
print(f"Random float between 0 and 1: {random_float}")

# Generate a random integer between a and b (inclusive)
random_int = random.randint(1, 10)
print(f"Random integer between 1 and 10: {random_int}")

# Generate a random integer using randrange
# randrange(stop) - from 0 to stop-1
# randrange(start, stop) - from start to stop-1
# randrange(start, stop, step) - from start to stop-1 with step
random_range = random.randrange(1, 10, 2)  # Odd numbers between 1 and 9
print(f"Random odd number between 1 and 9: {random_range}")

# 2. Random Choices
# Random choice from a list
fruits = ['apple', 'banana', 'orange', 'grape']
random_fruit = random.choice(fruits)
print(f"Random fruit: {random_fruit}")

# Random choices with replacement
random_fruits = random.choices(fruits, k=3)  # Choose 3 fruits with replacement
print(f"Random fruits with replacement: {random_fruits}")

# Random shuffle
random.shuffle(fruits)
print(f"Shuffled fruits: {fruits}")

# 3. Random Sampling
# Random sample without replacement
sample = random.sample(fruits, 2)  # Choose 2 unique fruits
print(f"Random sample of 2 fruits: {sample}")

# 4. Random with Weights
# Random choice with weighted probability
weights = [0.1, 0.3, 0.4, 0.2]  # Corresponds to fruits list
weighted_choice = random.choices(fruits, weights=weights, k=1)[0]
print(f"Weighted random choice: {weighted_choice}")

# 5. Random Gaussian Distribution
# Generate a random number from Gaussian distribution
# gauss(mu, sigma) - mean and standard deviation
random_gaussian = random.gauss(0, 1)
print(f"Random number from Gaussian distribution: {random_gaussian}")

# 6. Setting Seed for Reproducibility
random.seed(42)  # Set seed for reproducible results
print("\nAfter setting seed:")
print(random.random())  # Will always be the same with seed 42

# 7. Random Between Two Numbers
# Generate a random float between two numbers
random_between = random.uniform(1.5, 2.5)
print(f"Random float between 1.5 and 2.5: {random_between}")
