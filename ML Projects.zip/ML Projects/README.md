# Deep Learning Models Collection

A comprehensive collection of deep learning models ranging from basic neural networks to advanced architectures like diffusion models.

## Project Structure

```
├── models/           # Contains all model implementations
│   ├── vanilla_nn/  # Basic neural networks
│   ├── cnn/         # Convolutional Neural Networks
│   ├── rnn/         # Recurrent Neural Networks
│   ├── transformers/ # Transformer architectures
│   └── diffusion/    # Diffusion models
├── data/            # Data handling and preprocessing
│   ├── datasets/    # Dataset implementations
│   └── preprocessing/ # Data preprocessing utilities
├── utils/           # Utility functions and helpers
├── notebooks/       # Jupyter notebooks for experimentation
└── tests/           # Test files
```

## Installation

```bash
pip install -r requirements.txt
```

## Usage

Each model implementation will include:
- Model architecture
- Training loop
- Evaluation metrics
- Example usage
- Configuration options

## Contributing

Feel free to add new model implementations or improve existing ones. Make sure to follow the project structure and include comprehensive documentation.
