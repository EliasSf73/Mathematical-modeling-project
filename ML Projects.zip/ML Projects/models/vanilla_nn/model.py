import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional

class VanillaNN(nn.Module):
    def __init__(
        self,
        input_size: int,
        hidden_sizes: List[int],
        output_size: int,
        activation: str = "relu",
        dropout: float = 0.0,
        use_batchnorm: bool = False
    ):
        """
        Vanilla Neural Network implementation
        
        Args:
            input_size: Size of input features
            hidden_sizes: List of hidden layer sizes
            output_size: Size of output layer
            activation: Activation function to use ('relu', 'tanh', 'sigmoid')
            dropout: Dropout probability
            use_batchnorm: Whether to use batch normalization
        """
        super().__init__()
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.activation = activation
        self.dropout = dropout
        self.use_batchnorm = use_batchnorm

        # TODO: Implement the model architecture
        self.layers = nn.ModuleList()
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through the network
        
        Args:
            x: Input tensor of shape (batch_size, input_size)
            
        Returns:
            Output tensor of shape (batch_size, output_size)
        """
        # TODO: Implement the forward pass
        pass

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """
        Make predictions using the trained model
        
        Args:
            x: Input tensor
            
        Returns:
            Predicted output
        """
        return self.forward(x)

    def get_model_summary(self) -> str:
        """
        Get a summary of the model architecture
        
        Returns:
            String representation of model architecture
        """
        # TODO: Implement model summary
        pass
