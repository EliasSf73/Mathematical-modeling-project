class VanillaNNConfig:
    """
    Configuration class for Vanilla Neural Network
    """
    def __init__(
        self,
        input_size: int,
        hidden_sizes: List[int],
        output_size: int,
        activation: str = "relu",
        dropout: float = 0.0,
        use_batchnorm: bool = False,
        learning_rate: float = 0.001,
        optimizer: str = "adam",
        batch_size: int = 32,
        num_epochs: int = 10,
        device: str = "cpu"
    ):
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.activation = activation
        self.dropout = dropout
        self.use_batchnorm = use_batchnorm
        self.learning_rate = learning_rate
        self.optimizer = optimizer
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.device = device

    def get_model_params(self) -> dict:
        """
        Get parameters needed for model initialization
        """
        return {
            'input_size': self.input_size,
            'hidden_sizes': self.hidden_sizes,
            'output_size': self.output_size,
            'activation': self.activation,
            'dropout': self.dropout,
            'use_batchnorm': self.use_batchnorm
        }

    def get_training_params(self) -> dict:
        """
        Get parameters needed for training
        """
        return {
            'learning_rate': self.learning_rate,
            'optimizer': self.optimizer,
            'batch_size': self.batch_size,
            'num_epochs': self.num_epochs,
            'device': self.device
        }
